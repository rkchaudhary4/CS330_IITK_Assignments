#include <stdio.h>

int main()
{
	int i;
	for(i = 0; i < 10; ++i){
		printf("PS_OUTPUT_LINE_%d\n", i);
	}
	return 0;

}
